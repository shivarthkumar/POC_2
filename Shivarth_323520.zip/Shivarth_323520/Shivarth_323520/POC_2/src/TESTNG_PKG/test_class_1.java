package TESTNG_PKG;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.account_page;
import BASE_CLASSES.home_page;
import BASE_CLASSES.log_class;
import BASE_CLASSES.login_page;
import UTILITIES.Person;
import UTILITIES.excel_operations;

public class test_class_1 {
	int status;
	WebDriver dr;
	ArrayList<Person> user;
	account_page obj_account;
	home_page obj_home;
	login_page obj_login;
	Logger log;
	log_class obj_log;
	@BeforeClass
	public void BC() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		user = new ArrayList<Person>(3);
		log = Logger.getLogger("devpinoyLogger");
		excel_operations.read_excel(user);
		obj_home = new home_page(dr);
		obj_home.launch_browser();
		obj_account = new account_page(dr);
		obj_login = new login_page(dr);
		obj_log = new log_class();
		status = 1;
	}
	@Test(priority=1)
	public void f1() {
		
		SoftAssert sa = new SoftAssert();
		String actual = obj_home.verify_title();
		String expected = "My Store";
		sa.assertEquals(actual, expected);
		obj_log.writeLog("verify home page title", actual, expected);
		sa.assertAll();
	}
	@Test(priority=2)
	public void f2() {
		SoftAssert sa = new SoftAssert();
		String actual = obj_home.verify_signin();
		String expected = "Sign in";
		sa.assertEquals(actual, expected);
		obj_log.writeLog("verify signin", actual, expected);
		obj_home.click_signin();
		sa.assertAll();
		
	}
	@Test(priority=3)
	public void f3() {
		SoftAssert sa = new SoftAssert();
		obj_home.click_signin();
		String actual = obj_login.verify_login_page_title();
		String expected = "Login - My Store";
		sa.assertEquals(actual, expected);
		obj_log.writeLog("verify login page title", actual, expected);
		sa.assertAll();
	}
}

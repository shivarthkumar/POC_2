package TESTNG_PKG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class test_class_2 extends test_class_1{
	@DataProvider(name="data")
	public String[][] dataprovider() {
		String login_data [][] = new String [user.size()][3];
		for(int i=0;i<user.size();i++) {
			login_data[i][0] = user.get(i).email;
			login_data[i][1] = user.get(i).password;
			login_data[i][2] = user.get(i).expected;
		}
		return login_data;
	}
	@Test(priority=4,dataProvider="data")
	public void test_method(String email,String password,String expected) {
		SoftAssert sa = new SoftAssert();
		obj_login.perform_login(email, password);
		obj_login.click_signin_button();
		String actual = obj_account.verify_account();
		obj_log.writeLog("verify username", actual, expected);
		sa.assertEquals(actual, expected);
		sa.assertAll();		
	}
}

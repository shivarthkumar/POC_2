package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class account_page extends home_page{
	@FindBy(xpath="//a[@title=\"Log me out\"]")
	WebElement signout_button;
	@FindBy(xpath="//a[@title=\"View my customer account\"]")
	WebElement user_name;
	public account_page(WebDriver dr) {
		super(dr);
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	public String verify_account() {
		String str = user_name.getText();
		click_signout();
		return str;
	}
	public void click_signout() {
		signout_button.click();
	}
}

package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class home_page {
	WebDriver dr;
	@FindBy(xpath="//a[@title=\"Log in to your customer account\"]")
	WebElement signin_button_1;
	public home_page(WebDriver dr){
		this.dr = dr;
	}
	public void launch_browser() {
		dr.get("http://automationpractice.com/index.php");
		PageFactory.initElements(dr, this);
	}
	public void click_signin() {
		signin_button_1.click();
	}
	public String verify_title() {
		try {
			WebDriverWait wt = new WebDriverWait(dr,10);
			wt.until(ExpectedConditions.titleIs(dr.getTitle()));
			return dr.getTitle();
		}catch(Exception e) {
			System.out.println("Title Element not found in home page");
			return "xxxx";
		}
	}
	public String verify_signin() {
		return signin_button_1.getText();
	}
}
